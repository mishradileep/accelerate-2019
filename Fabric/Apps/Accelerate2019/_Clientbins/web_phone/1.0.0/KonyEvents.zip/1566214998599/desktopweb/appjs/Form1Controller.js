define("userForm1Controller", {
    uploadToS3: function() {
        this.view.s3uploadmobile.uploadSuccess = this.uploadMaterialSuccess.bind(this);
        this.view.s3uploadmobile.browseFilesandUpload("*/*");
    },
    uploadMaterialSuccess: function(link) {
        kony.application.dismissLoadingScreen();
        this.view.TextField0b74d8ec7fdc744.text = link;
    }
});
define("Form1ControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for Button0iffccb65d07247 **/
    AS_Button_f593338ec12d438fab32fd146c114878: function AS_Button_f593338ec12d438fab32fd146c114878(eventobject) {
        var self = this;
        this.uploadToS3();
    }
});
define("Form1Controller", ["userForm1Controller", "Form1ControllerActions"], function() {
    var controller = require("userForm1Controller");
    var controllerActions = ["Form1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
