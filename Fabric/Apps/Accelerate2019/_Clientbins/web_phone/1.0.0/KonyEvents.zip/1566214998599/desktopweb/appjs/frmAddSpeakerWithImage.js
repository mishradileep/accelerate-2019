define("frmAddSpeakerWithImage", function() {
    return function(controller) {
        function addWidgetsfrmAddSpeakerWithImage() {
            this.setDefaultUnit(kony.flex.DP);
            var TextField0f67e213edfdd41 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "TextField0f67e213edfdd41",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "264dp",
                "placeholder": "speakerName",
                "secureTextEntry": false,
                "skin": "defTextBoxNormal",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "140dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var CopyTextField0f18c809daf0342 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "CopyTextField0f18c809daf0342",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "264dp",
                "placeholder": "Title",
                "secureTextEntry": false,
                "skin": "defTextBoxNormal",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "30dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var TextArea0ba64619983974f = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "focusSkin": "defTextAreaFocus",
                "height": "120dp",
                "id": "TextArea0ba64619983974f",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "280dp",
                "numberOfVisibleLines": 3,
                "placeholder": "Speaker bio",
                "skin": "defTextAreaNormal",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "40dp",
                "width": "40%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            var flexUploadGalleryVAlue = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": true,
                "height": "100dp",
                "id": "flexUploadGalleryVAlue",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "12dp",
                "width": "40%",
                "zIndex": 2
            }, {}, {});
            flexUploadGalleryVAlue.setDefaultUnit(kony.flex.DP);
            var flexGalleryBrowseMain = new kony.ui.FlexContainer({
                "centerX": "50%",
                "clipBounds": true,
                "height": "45dp",
                "id": "flexGalleryBrowseMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "20dp",
                "isModalContainer": false,
                "skin": "sknflexfffBR1",
                "top": "0%",
                "width": "99%",
                "zIndex": 1
            }, {}, {});
            flexGalleryBrowseMain.setDefaultUnit(kony.flex.DP);
            var lblBrowseCSV = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblBrowseCSV",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl343e48AB100",
                "text": "Browse your files",
                "top": "0dp",
                "width": "70%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblGalleryVert = new kony.ui.Label({
                "centerY": "50%",
                "height": "90%",
                "id": "lblGalleryVert",
                "isVisible": true,
                "left": "1%",
                "skin": "sknheaderlblLine",
                "top": "0%",
                "width": "0.20%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnGalleryBrowse = new kony.ui.Button({
                "height": "100%",
                "id": "btnGalleryBrowse",
                "isVisible": true,
                "left": "1%",
                "onClick": controller.AS_Button_a950acf079484a009b15d4a5e79d08ff,
                "skin": "sknbtn00a0ddAM120",
                "text": "Browse",
                "top": "0%",
                "width": "25%",
                "zIndex": 5
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flexGalleryBrowseMain.add(lblBrowseCSV, lblGalleryVert, btnGalleryBrowse);
            var lblUploadCSVSuccess = new kony.ui.Label({
                "height": "30dp",
                "id": "lblUploadCSVSuccess",
                "isVisible": false,
                "left": "63.46%",
                "skin": "sknlbl00a0ddAL80",
                "text": "Upload Successful",
                "top": "46%",
                "width": "36.09%",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_RIGHT,
                "padding": [2, 2, 0, 0],
                "paddingInPixel": false
            }, {});
            flexUploadGalleryVAlue.add(flexGalleryBrowseMain, lblUploadCSVSuccess);
            this.add(TextField0f67e213edfdd41, CopyTextField0f18c809daf0342, TextArea0ba64619983974f, flexUploadGalleryVAlue);
        };
        return [{
            "addWidgets": addWidgetsfrmAddSpeakerWithImage,
            "enabledForIdleTimeout": false,
            "id": "frmAddSpeakerWithImage",
            "layoutType": kony.flex.FLOW_VERTICAL,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FLOW_VERTICAL,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});