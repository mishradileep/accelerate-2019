define("userfrmAddSpeakerWithImageController", {
    //Type your controller code here 
});
define("frmAddSpeakerWithImageControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onClick defined for btnGalleryBrowse **/
    AS_Button_a950acf079484a009b15d4a5e79d08ff: function AS_Button_a950acf079484a009b15d4a5e79d08ff(eventobject) {
        var self = this;
        this.browseCSVFile();
    }
});
define("frmAddSpeakerWithImageController", ["userfrmAddSpeakerWithImageController", "frmAddSpeakerWithImageControllerActions"], function() {
    var controller = require("userfrmAddSpeakerWithImageController");
    var controllerActions = ["frmAddSpeakerWithImageControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
