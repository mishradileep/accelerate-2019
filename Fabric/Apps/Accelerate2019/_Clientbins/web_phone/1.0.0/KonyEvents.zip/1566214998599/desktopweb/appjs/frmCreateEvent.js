define("frmCreateEvent", function() {
    return function(controller) {
        function addWidgetsfrmCreateEvent() {
            this.setDefaultUnit(kony.flex.DP);
            var hamburgerevents = new com.konymp.hamburgerevents({
                "clipBounds": true,
                "height": "100%",
                "id": "hamburgerevents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "overrides": {
                    "hamburgerevents": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            hamburgerevents.logoutSuccess = controller.AS_UWI_bfa44cccdc4f4b4e8a4d539255334952;
            hamburgerevents.eventTypeChoosen = controller.AS_UWI_a6eb435ad5024f839492cf933e9cbd76;
            hamburgerevents.onClickOfEditProfile = controller.AS_UWI_jb6b218cf1c641918565049528121655;
            var createEventAndSessions = new com.konymp.createEventAndSessions({
                "clipBounds": true,
                "height": "100%",
                "id": "createEventAndSessions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "80%",
                "overrides": {
                    "createEventAndSessions": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            createEventAndSessions.onPublishSuccess = controller.AS_UWI_fb135bcf2d5e434e8c95f661a893525a;
            this.add(hamburgerevents, createEventAndSessions);
        };
        return [{
            "addWidgets": addWidgetsfrmCreateEvent,
            "enabledForIdleTimeout": false,
            "id": "frmCreateEvent",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFormGrey",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1200]
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});