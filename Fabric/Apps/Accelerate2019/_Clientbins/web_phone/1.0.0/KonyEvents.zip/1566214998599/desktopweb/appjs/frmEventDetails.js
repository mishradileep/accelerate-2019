define("frmEventDetails", function() {
    return function(controller) {
        function addWidgetsfrmEventDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flexEventDetailMain = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "100%",
                "id": "flexEventDetailMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%"
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flexEventDetailMain.setDefaultUnit(kony.flex.DP);
            var flxLeftMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLeftMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 5
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLeftMenu.setDefaultUnit(kony.flex.DP);
            var hamburgerevents = new com.konymp.hamburgerevents({
                "clipBounds": true,
                "height": "100%",
                "id": "hamburgerevents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "hamburgerevents": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            hamburgerevents.logoutSuccess = controller.AS_UWI_d22ddafa8b7c4625b24a8d8ab10ee2a7;
            hamburgerevents.logoutFailure = controller.AS_UWI_f2061381206647dcb7d4a60d16f3a195;
            hamburgerevents.eventTypeChoosen = controller.AS_UWI_g6db7f014bbe4cb8b8389b451f8e2812;
            hamburgerevents.onClickOfEditProfile = controller.AS_UWI_ed1440afbb1c4e83a1a20e04d5093228;
            hamburgerevents.createEvent = controller.AS_UWI_c0cf9312f4154b60bde3e6ff94d62904;
            hamburgerevents.showLoading = controller.AS_UWI_g6aff3a846544d13a2d8e609983f795c;
            flxLeftMenu.add(hamburgerevents);
            var flxEventDetailsWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxEventDetailsWrapper",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "80%",
                "zIndex": 5
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxEventDetailsWrapper.setDefaultUnit(kony.flex.DP);
            var flxBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "10%",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var flxBackImag = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "flxBackImag",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_ca97ec9898004758b242b51399658ad2,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBackImag.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "height": "100%",
                "id": "imgBack",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "back_button.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBackImag.add(imgBack);
            var lblBack = new kony.ui.Label({
                "centerY": "50%",
                "height": "30%",
                "id": "lblBack",
                "isVisible": true,
                "left": "10px",
                "skin": "sknlblBack00a0dd",
                "text": "Back To All Events",
                "top": "34dp",
                "width": "19.79%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(flxBackImag, lblBack);
            var flxDetailsContainer = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": true,
                "enableScrolling": true,
                "height": "90%",
                "horizontalScrollIndicator": true,
                "id": "flxDetailsContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "10%",
                "verticalScrollIndicator": true,
                "width": "100%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxDetailsContainer.setDefaultUnit(kony.flex.DP);
            var eventdetails = new com.konymp.eventdetails({
                "clipBounds": true,
                "height": "100%",
                "id": "eventdetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "eventdetails": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            eventdetails.onLocationRowClick = controller.AS_UWI_f6e0eb11c7e649cd9c5e3b8a6e58d677;
            eventdetails.onSessionRowClick = controller.AS_UWI_a835283ad34f4f7e84f57e7a5716b6e1;
            eventdetails.onViewAttendees = controller.AS_UWI_g8936bd2dd0b4f64b77de8ab876b65d9;
            eventdetails.onViewOpinions = controller.AS_UWI_i601f58a81b546e48ea799ddc7c56b0d;
            eventdetails.invokeLoadingScreen = controller.AS_UWI_fc2039c4955c4f5eb2a64b7dfc23d6af;
            var flxPopUpBrower = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "-50%",
                "clipBounds": true,
                "height": "80%",
                "id": "flxPopUpBrower",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "80%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxPopUpBrower.setDefaultUnit(kony.flex.DP);
            var flxBrowser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "90%",
                "id": "flxBrowser",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "270dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "330dp",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBrowser.setDefaultUnit(kony.flex.DP);
            var pdfBrowser = new kony.ui.Browser({
                "centerX": "50%",
                "centerY": "50%",
                "detectTelNumber": true,
                "enableZoom": false,
                "height": "100%",
                "htmlString": "Browser",
                "id": "pdfBrowser",
                "isVisible": true,
                "width": "100%",
                "zIndex": 1
            }, {}, {});
            flxBrowser.add(pdfBrowser);
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "50dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "93%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_hb79a6e2afbc43adb80fe8fde2987e67,
                "skin": "slFbox",
                "top": "0%",
                "width": "50dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "100%",
                "id": "imgClose",
                "isVisible": false,
                "left": "17dp",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "123dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose);
            flxPopUpBrower.add(flxBrowser, flxClose);
            flxDetailsContainer.add(eventdetails, flxPopUpBrower);
            flxEventDetailsWrapper.add(flxBack, flxDetailsContainer);
            var flexAttendeeList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flexAttendeeList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknAttendeeListContainerDW",
                "top": "0%",
                "width": "100%",
                "zIndex": 5
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flexAttendeeList.setDefaultUnit(kony.flex.DP);
            var attendeesListView = new com.konymp.attendeesListView({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "80%",
                "id": "attendeesListView",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknAttendeeDetailMobile",
                "top": "0dp",
                "width": "80%",
                "overrides": {
                    "attendeesListView": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxCloseDiscussion = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxCloseDiscussion",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "89.5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "7.5%",
                "width": "20dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxCloseDiscussion.setDefaultUnit(kony.flex.DP);
            var imgCloseDiscussion = new kony.ui.Image2({
                "height": "100%",
                "id": "imgCloseDiscussion",
                "isVisible": true,
                "left": "0dp",
                "onTouchEnd": controller.AS_Image_a636e43e001a41c49325e84c75d48343,
                "skin": "slImage",
                "src": "close.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCloseDiscussion.add(imgCloseDiscussion);
            flexAttendeeList.add(attendeesListView, flxCloseDiscussion);
            var discussionList = new com.konymp.discussionList({
                "clipBounds": true,
                "height": "100%",
                "id": "discussionList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknDiscussionListBg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "overrides": {
                    "discussionList": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            discussionList.invokeLoadingScreen = controller.AS_UWI_f03825454a17481eb00fb1165980c845;
            var flxBlocker = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxBlocker",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknGreyBlocler",
                "top": "0dp",
                "width": "100%",
                "zIndex": 6
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBlocker.setDefaultUnit(kony.flex.DP);
            var flxLevel2Container = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "90%",
                "id": "flxLevel2Container",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "65%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLevel2Container.setDefaultUnit(kony.flex.DP);
            var flxAirContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "85%",
                "id": "flxAirContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknAirCurve",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxAirContainer.setDefaultUnit(kony.flex.DP);
            var opinionclient = new com.konymp.opinionclient({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "opinionclient",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknWhiteCurvedBackground",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "opinionclient": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            opinionclient.eventId = "1";
            opinionclient.sessionId = "1";
            opinionclient.opinionType = "Poll";
            opinionclient.userId = "1";
            opinionclient.showLoading = controller.AS_UWI_gcdfc92250564206bf365acc4d24b9a4;
            flxAirContainer.add(opinionclient);
            var CopyflxClose0f27ff29a1fc845 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "CopyflxClose0f27ff29a1fc845",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "94.80%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_j010996a749f41438372761992de5220,
                "skin": "slFbox",
                "top": "5%",
                "width": "20dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            CopyflxClose0f27ff29a1fc845.setDefaultUnit(kony.flex.DP);
            var CopyimgClose0e609caadf7c247 = new kony.ui.Image2({
                "height": "100%",
                "id": "CopyimgClose0e609caadf7c247",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "close.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            CopyflxClose0f27ff29a1fc845.add(CopyimgClose0e609caadf7c247);
            flxLevel2Container.add(flxAirContainer, CopyflxClose0f27ff29a1fc845);
            flxBlocker.add(flxLevel2Container);
            var flxThrobberWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxThrobberWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxLoader",
                "top": "0dp",
                "width": "100%",
                "zIndex": 50
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxThrobberWrapper.setDefaultUnit(kony.flex.DP);
            var flxThrobber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxThrobber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxThrobber",
                "top": "0dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxThrobber.setDefaultUnit(kony.flex.DP);
            var imgLoader = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "8dp",
                "id": "imgLoader",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "loading_strip.gif",
                "top": 0,
                "width": "56dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxThrobber.add(imgLoader);
            flxThrobberWrapper.add(flxThrobber);
            flexEventDetailMain.add(flxLeftMenu, flxEventDetailsWrapper, flexAttendeeList, discussionList, flxBlocker, flxThrobberWrapper);
            this.add(flexEventDetailMain);
        };
        return [{
            "addWidgets": addWidgetsfrmEventDetails,
            "enabledForIdleTimeout": false,
            "id": "frmEventDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFormGrey",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [479, 1200, 1366],
            "onBreakpointChange": controller.AS_Form_f0f937fa99984d4498713d8d4f8ef486
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});