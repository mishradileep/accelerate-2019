define("userfrmEventDetailsController", {
    //Type your controller code here 
    onNavigate: function(eventDetail) {
        if (eventDetail !== undefined) {
            this._eventDetails = eventDetail;
            var startDate = new Date(eventDetail.start_date.split(' ')[0]);
            var endDate = new Date(eventDetail.end_date.split(' ')[0]);
            var months = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
            var date;
            if (startDate.getDate() == endDate.getDate()) {
                date = startDate.getDate() + "";
            } else {
                date = startDate.getDate() + "-" + endDate.getDate();
            }
            var bannerURL = "eventsdef_1.png";
            if (eventDetail.event_banners && eventDetail.event_banners.length) {
                bannerURL = eventDetail.event_banners[0].banner_url;
            }
            this.view.eventdetails.setEventDetails(eventDetail.name, eventDetail.event_category, date, months[startDate.getMonth()] + " " + startDate.getFullYear(), eventDetail.long_desc, bannerURL, eventDetail, eventDetail.event_id); //eventDetail.attendeesList,eventDetail.eventBanner);
            var addressLine1 = (eventDetail.location[0].addressLine1) ? eventDetail.location[0].addressLine1 : "";
            var cityName = (eventDetail.location[0].cityname) ? eventDetail.location[0].cityname : "";
            var location = (eventDetail.location[0].location) ? eventDetail.location[0].location : "";
            var eventLocation = location + ", " + addressLine1 + ", " + cityName;
            this.view.eventdetails.setEventLocation(eventLocation, eventDetail.location[0].latitude, eventDetail.location[0].longitude, eventDetail.event_inner_location);
        }
    },
    openPdfInBrower: function(innerLocation) {
        this.view.flxPopUpBrower.isVisible = false;
        this.view.pdfBrowser.requestURLConfig = innerLocation;
    },
    dimissPopup: function() {
        this.view.flxPopUpBrower.isVisible = false;
    },
    clickedOnSessionDetails: function() {
        var navi = new kony.mvc.Navigation("frmSessionDetails");
        navi.navigate(this._eventDetails.sessionData[0]);
    },
    navigateToSessionDetails: function(session) {
        session.event_name = this._eventDetails.name;
        session.event_type = this._eventDetails.event_category;
        var navi = new kony.mvc.Navigation("frmSessionDetails");
        navi.navigate(session);
    },
    setAttendeeData: function(attendees) {
        this.view.attendeesListView.setWidgetDataMap({
            "lblUserName": "userName",
            "lblUserMail": "mail",
            "imgProfilePic": "picUrl"
        });
        var filter = [];
        if (attendees) {
            for (var iterateAttendees = 0; iterateAttendees < attendees.length; iterateAttendees++) {
                var attendee = attendees[iterateAttendees];
                if (attendee.profileVisibility) {
                    filter.push(attendee);
                }
            }
        }
        this.view.attendeesListView.setAttendeesData(filter, this._eventDetails.event_type);
        this.view.flexAttendeeList.isVisible = true;
    },
    showDiscussionList: function(session_data) {
        var config;
        if (session_data.event_session_id) {
            config = {
                "event_id": this._eventDetails.event_id,
                "session_id": session_data.event_session_id,
                "user_id": kony.store.getItem("currentUserInfo").user_id,
                "name": session_data.session_name,
                "username": kony.store.getItem("currentUserInfo").first_name,
                "user_profile": kony.store.getItem("currentUserInfo").profile_pic_url,
            };
        } else {
            config = {
                "event_id": this._eventDetails.event_id,
                "user_id": kony.store.getItem("currentUserInfo").user_id,
                "name": session_data.name,
                "username": kony.store.getItem("currentUserInfo").first_name,
                "user_profile": kony.store.getItem("currentUserInfo").profile_pic_url,
            };
        }
        this.view.discussionList.setDiscussion(config);
        this.view.discussionList.isVisible = true;
    },
    setSurveys: function(eventSessionData, opinionType) {
        this.view.flxAirContainer.shadowDepth = 5;
        this.view.flxAirContainer.shadowType = constants.VIEW_BOUNDS_SHADOW;
        this.view.opinionclient.eventId = this._eventDetails.event_id;
        this.view.opinionclient.opinionType = opinionType;
        if (eventSessionData.event_session_id) {
            this.view.opinionclient.sessionId = eventSessionData.event_session_id;
            this.view.opinionclient.getOpinions(eventSessionData.session_name);
            this.view.forceLayout();
        } else {
            this.view.opinionclient.sessionId = null;
            this.view.opinionclient.getOpinions(eventSessionData.name);
            this.view.forceLayout();
        }
        this.view.flxBlocker.isVisible = true;
        this.view.forceLayout();
        this.view.forceLayout();
        this.view.forceLayout();
    },
    setOpinions: function(eventObject, type) {
        if (type != 4) {
            this.setSurveys(eventObject, type);
        } else {
            this.showDiscussionList(eventObject);
        }
    },
    dimissPopupSchedular: function() {
        this.view.flxBlocker.isVisible = false;
    },
    navigateToEventList: function(text, id) {
        var config = {
            "text": text,
            "id": id
        };
        var ntf = new kony.mvc.Navigation("frmEventsList");
        ntf.navigate(config);
    },
    navigateFrmEvenetsList: function(text, id) {
        var index = id[id.length - 1];
        if (index != 3) {
            var naviObj = new kony.mvc.Navigation("frmEventsList");
            var eventObject = {
                "text": text,
                "id": id
            };
            naviObj.navigate(eventObject);
        }
    },
    toggleLoadingScreen: function(isLoadingVisible) {
        this.view.flxThrobber.isVisible = isLoadingVisible;
        this.view.forceLayout();
    },
    onBreakPointChange: function(eventobject, breakpoint) {
        if (breakpoint <= 479) {
            this.view.flxLeftMenu.isVisible = false;
            this.view.flxEventDetailsWrapper.left = "0%";
            this.view.flxEventDetailsWrapper.width = "100%";
            this.view.flxBack.width = "100%";
            this.view.flxBack.height = "4%";
            this.view.lblBack.top = "15dp";
            this.view.lblBack.height = "100%";
            this.view.lblBack.width = "80%";
            this.view.attendeesListView.width = "100%";
            this.view.attendeesListView.height = "80%";
            this.view.attendeesListView.changeLayoutForBreakPoint(breakpoint);
            this.view.eventdetails.changeLayoutForBreakPoint(breakpoint);
        }
    },
    onChangeInBreakpoint: function(breakpoint) {
        setBreakpointValue(breakpoint);
        this.view.opinionclient.onBreakPointChange(breakpoint);
        if (breakpoint > 479 && breakpoint <= 1200) {
            this.view.flxClose.top = "4%";
        } else if (breakpoint <= 479) {
            this.view.discussionList.onBreakPointChange(breakpoint);
            this.view.flxClose.top = "5%";
            this.view.flxLevel2Container.width = "100%";
            this.view.flxAirContainer.width = "100%";
            this.view.opinionclient.width = "100%";
            this.view.CopyflxClose0f27ff29a1fc845.top = "3%";
            this.view.forceLayout();
        }
    }
});
define("frmEventDetailsControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** logoutSuccess defined for hamburgerevents **/
    AS_UWI_d22ddafa8b7c4625b24a8d8ab10ee2a7: function AS_UWI_d22ddafa8b7c4625b24a8d8ab10ee2a7() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLogin");
        ntf.navigate();
    },
    /** logoutFailure defined for hamburgerevents **/
    AS_UWI_f2061381206647dcb7d4a60d16f3a195: function AS_UWI_f2061381206647dcb7d4a60d16f3a195() {
        var self = this;
        alert("logout operation failed");
    },
    /** eventTypeChoosen defined for hamburgerevents **/
    AS_UWI_g6db7f014bbe4cb8b8389b451f8e2812: function AS_UWI_g6db7f014bbe4cb8b8389b451f8e2812(text, id) {
        var self = this;
        this.navigateFrmEvenetsList(text, id);
    },
    /** onClickOfEditProfile defined for hamburgerevents **/
    AS_UWI_ed1440afbb1c4e83a1a20e04d5093228: function AS_UWI_ed1440afbb1c4e83a1a20e04d5093228() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProfile");
        ntf.navigate();
    },
    /** createEvent defined for hamburgerevents **/
    AS_UWI_c0cf9312f4154b60bde3e6ff94d62904: function AS_UWI_c0cf9312f4154b60bde3e6ff94d62904() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmCreateEvent");
        ntf.navigate();
    },
    /** showLoading defined for hamburgerevents **/
    AS_UWI_g6aff3a846544d13a2d8e609983f795c: function AS_UWI_g6aff3a846544d13a2d8e609983f795c(bool) {
        var self = this;
        this.toggleLoadingScreen(bool);
    },
    /** onClick defined for flxBackImag **/
    AS_FlexContainer_ca97ec9898004758b242b51399658ad2: function AS_FlexContainer_ca97ec9898004758b242b51399658ad2(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmEventsList");
        ntf.navigate();
    },
    /** onLocationRowClick defined for eventdetails **/
    AS_UWI_f6e0eb11c7e649cd9c5e3b8a6e58d677: function AS_UWI_f6e0eb11c7e649cd9c5e3b8a6e58d677(innerLocationData) {
        var self = this;
        this.openPdfInBrower(innerLocationData);
    },
    /** onSessionRowClick defined for eventdetails **/
    AS_UWI_a835283ad34f4f7e84f57e7a5716b6e1: function AS_UWI_a835283ad34f4f7e84f57e7a5716b6e1(session) {
        var self = this;
        this.navigateToSessionDetails(session);
    },
    /** onViewAttendees defined for eventdetails **/
    AS_UWI_g8936bd2dd0b4f64b77de8ab876b65d9: function AS_UWI_g8936bd2dd0b4f64b77de8ab876b65d9(attendees) {
        var self = this;
        this.setAttendeeData(attendees);
    },
    /** onViewOpinions defined for eventdetails **/
    AS_UWI_i601f58a81b546e48ea799ddc7c56b0d: function AS_UWI_i601f58a81b546e48ea799ddc7c56b0d(eventobject, type) {
        var self = this;
        this.setOpinions(eventobject, type);
    },
    /** invokeLoadingScreen defined for eventdetails **/
    AS_UWI_fc2039c4955c4f5eb2a64b7dfc23d6af: function AS_UWI_fc2039c4955c4f5eb2a64b7dfc23d6af(isLoadingVisible) {
        var self = this;
        this.toggleLoadingScreen(isLoadingVisible)
    },
    /** onClick defined for flxClose **/
    AS_FlexContainer_hb79a6e2afbc43adb80fe8fde2987e67: function AS_FlexContainer_hb79a6e2afbc43adb80fe8fde2987e67(eventobject) {
        var self = this;
        this.dimissPopup();
    },
    /** onTouchEnd defined for imgCloseDiscussion **/
    AS_Image_a636e43e001a41c49325e84c75d48343: function AS_Image_a636e43e001a41c49325e84c75d48343(eventobject, x, y) {
        var self = this;
        this.view.flexAttendeeList.setVisibility(false);
        this.view.forceLayout();
    },
    /** invokeLoadingScreen defined for discussionList **/
    AS_UWI_f03825454a17481eb00fb1165980c845: function AS_UWI_f03825454a17481eb00fb1165980c845(isLoadingVisible) {
        var self = this;
        this.view.flxThrobberWrapper.isVisible = isLoadingVisible;
        this.view.forceLayout();
    },
    /** showLoading defined for opinionclient **/
    AS_UWI_gcdfc92250564206bf365acc4d24b9a4: function AS_UWI_gcdfc92250564206bf365acc4d24b9a4(bool) {
        var self = this;
        this.toggleLoadingScreen(bool);
    },
    /** onClick defined for CopyflxClose0f27ff29a1fc845 **/
    AS_FlexContainer_j010996a749f41438372761992de5220: function AS_FlexContainer_j010996a749f41438372761992de5220(eventobject) {
        var self = this;
        this.dimissPopupSchedular();
    },
    /** onBreakpointChange defined for frmEventDetails **/
    AS_Form_f0f937fa99984d4498713d8d4f8ef486: function AS_Form_f0f937fa99984d4498713d8d4f8ef486(eventobject, breakpoint) {
        var self = this;
        this.onBreakPointChange(eventobject, breakpoint);
        this.onChangeInBreakpoint(breakpoint);
    }
});
define("frmEventDetailsController", ["userfrmEventDetailsController", "frmEventDetailsControllerActions"], function() {
    var controller = require("userfrmEventDetailsController");
    var controllerActions = ["frmEventDetailsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
