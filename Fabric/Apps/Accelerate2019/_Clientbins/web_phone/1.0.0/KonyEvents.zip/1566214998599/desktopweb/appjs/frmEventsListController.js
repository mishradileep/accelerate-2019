define("userfrmEventsListController", {
    //Type your controller code here 
    showEventsListToUser: function(text, id) {
        this.toggleProfileWithHamburger(true);
        this.view.headermenubar.editHeader(text, id);
    },
    toggleProfileWithHamburger: function(value) {
        this.view.headermenubar.isVisible = value;
        this.view.flxProfileContainer.isVisible = !value;
    },
    onNavigate: function(eventObject) {
        if (eventObject) {
            this.view.headermenubar.typeSelected(eventObject.text, eventObject.id);
        } else {
            this.view.headermenubar.typeSelected("All Events", "flx0");
        }
    },
    showLoadingScreen: function(bool) {
        this.view.flxThrobberWrapper.isVisible = bool;
    },
    controlNavigation: function() {
        alert("Click logout to exit from the application");
    },
    onChangeInBreakpoint: function(breakpoint) {
        this.view.headermenubar.onBreakPointChange(breakpoint);
    },
});
define("frmEventsListControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** eventChoosen defined for headermenubar **/
    AS_UWI_g6758d1351f64ef9b01c35a269ae9815: function AS_UWI_g6758d1351f64ef9b01c35a269ae9815(event) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmEventDetails");
        ntf.navigate(event);
    },
    /** editProfileChoosen defined for headermenubar **/
    AS_UWI_h6985be6421340319d53adfcb8883f32: function AS_UWI_h6985be6421340319d53adfcb8883f32() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProfile");
        ntf.navigate();
    },
    /** logoutSuccessEvent defined for headermenubar **/
    AS_UWI_b19b48a8d08f4e0cabad28caae406810: function AS_UWI_b19b48a8d08f4e0cabad28caae406810() {
        var self = this;
        var naviObj = new kony.mvc.Navigation("frmLogin");
        naviObj.navigate();
    },
    /** logoutFailureEvent defined for headermenubar **/
    AS_UWI_id08e8f86517477e9b775f80da99316a: function AS_UWI_id08e8f86517477e9b775f80da99316a() {
        var self = this;
        alert(" logout failed");
    },
    /** editEvent defined for headermenubar **/
    AS_UWI_h464d6d96c5c410294a3e95c7dfe12e8: function AS_UWI_h464d6d96c5c410294a3e95c7dfe12e8(event) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmCreateEvent");
        ntf.navigate(event);
    },
    /** showLoading defined for headermenubar **/
    AS_UWI_j9a1ebc1ae664062ad7a06ba2c8bcb75: function AS_UWI_j9a1ebc1ae664062ad7a06ba2c8bcb75(bool) {
        var self = this;
        this.showLoadingScreen(bool);
    },
    /** createEvent defined for headermenubar **/
    AS_UWI_f2639e3327b642739be155351d4e0b3f: function AS_UWI_f2639e3327b642739be155351d4e0b3f() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmCreateEvent");
        ntf.navigate();
    },
    /** postShow defined for frmEventsList **/
    AS_Form_e56a508fc6ee453aa2c51229a8918c49: function AS_Form_e56a508fc6ee453aa2c51229a8918c49(eventobject) {
        var self = this;
        try {
            kony.application.destroyForm("frmCreateEvent");
        } catch (err) {
            kony.print(err);
        }
    },
    /** onDeviceBack defined for frmEventsList **/
    AS_Form_c2402b8fee15434f909f94d11cb7821d: function AS_Form_c2402b8fee15434f909f94d11cb7821d(eventobject) {
        var self = this;
        this.controlNavigation();
    },
    /** onBreakpointChange defined for frmEventsList **/
    AS_Form_ad9be9019cbd460787b5e6a8b26b1774: function AS_Form_ad9be9019cbd460787b5e6a8b26b1774(eventobject, breakpoint) {
        var self = this;
        this.onChangeInBreakpoint(breakpoint);
    }
});
define("frmEventsListController", ["userfrmEventsListController", "frmEventsListControllerActions"], function() {
    var controller = require("userfrmEventsListController");
    var controllerActions = ["frmEventsListControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
