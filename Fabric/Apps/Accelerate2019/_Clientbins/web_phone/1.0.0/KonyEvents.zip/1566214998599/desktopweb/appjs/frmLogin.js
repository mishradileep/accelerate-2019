define("frmLogin", function() {
    return function(controller) {
        function addWidgetsfrmLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var eventslogin = new com.konymp.eventslogin({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "eventslogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknLoginBackground",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "eventslogin": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            eventslogin.loginSuccess = controller.AS_UWI_h58858c2b2a84ab2b1d87e78d9f7c46c;
            eventslogin.loginFailed = controller.AS_UWI_f54fef42bcdd476c82ad86fefece82d7;
            var lbl1 = new kony.ui.Label({
                "height": "2%",
                "id": "lbl1",
                "isVisible": true,
                "left": "62dp",
                "skin": "sknAvenirBook",
                "text": "test",
                "top": "250dp",
                "width": "55dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Copylbl0c5ae67c9ced942 = new kony.ui.Label({
                "height": "2%",
                "id": "Copylbl0c5ae67c9ced942",
                "isVisible": true,
                "left": "62dp",
                "skin": "sknAvenirHeavy",
                "text": "test",
                "top": "280dp",
                "width": "55dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Copylbl0d41ab03d09c740 = new kony.ui.Label({
                "height": "2%",
                "id": "Copylbl0d41ab03d09c740",
                "isVisible": true,
                "left": "62dp",
                "skin": "sknAvenirLight",
                "text": "test",
                "top": "320dp",
                "width": "55dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Copylbl0d92329482c3444 = new kony.ui.Label({
                "height": "2%",
                "id": "Copylbl0d92329482c3444",
                "isVisible": true,
                "left": "62dp",
                "skin": "sknAvenirMedium",
                "text": "test",
                "top": "350dp",
                "width": "55dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.add(eventslogin, lbl1, Copylbl0c5ae67c9ced942, Copylbl0d41ab03d09c740, Copylbl0d92329482c3444);
        };
        return [{
            "addWidgets": addWidgetsfrmLogin,
            "enabledForIdleTimeout": false,
            "id": "frmLogin",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [479, 1200, 1336],
            "onBreakpointChange": controller.AS_Form_g052cb2abed6440ca90860fda633d5d1
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});