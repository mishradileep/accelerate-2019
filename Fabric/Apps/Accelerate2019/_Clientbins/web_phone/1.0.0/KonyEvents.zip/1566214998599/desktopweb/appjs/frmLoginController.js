define("userfrmLoginController", {
    //Type your controller code here 
    showLoadingScreen: function(bool) {
        this.view.flxThrowbberWrapper.isVisible = bool;
    },
    onBreakPointChange: function(eventobject, breakpoint) {
        this.view.eventslogin.onBreakPointChange(breakpoint);
    }
});
define("frmLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** loginSuccess defined for eventslogin **/
    AS_UWI_h58858c2b2a84ab2b1d87e78d9f7c46c: function AS_UWI_h58858c2b2a84ab2b1d87e78d9f7c46c(userInfo, componentContext) {
        var self = this;
        //componentContext.flxThrobberWrapper.isVisible=false;
        kony.application.dismissLoadingScreen();
        var naviObj = new kony.mvc.Navigation("frmEventsList");
        naviObj.navigate();
    },
    /** loginFailed defined for eventslogin **/
    AS_UWI_f54fef42bcdd476c82ad86fefece82d7: function AS_UWI_f54fef42bcdd476c82ad86fefece82d7() {
        var self = this;
        kony.application.dismissLoadingScreen();
        alert(" login failed");
    },
    /** onBreakpointChange defined for frmLogin **/
    AS_Form_g052cb2abed6440ca90860fda633d5d1: function AS_Form_g052cb2abed6440ca90860fda633d5d1(eventobject, breakpoint) {
        var self = this;
        this.onBreakPointChange(eventobject, breakpoint);
    }
});
define("frmLoginController", ["userfrmLoginController", "frmLoginControllerActions"], function() {
    var controller = require("userfrmLoginController");
    var controllerActions = ["frmLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
