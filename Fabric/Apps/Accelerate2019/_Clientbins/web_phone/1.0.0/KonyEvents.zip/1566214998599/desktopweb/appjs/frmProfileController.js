define("userfrmProfileController", {
    //Type your controller code here 
    navigateFrmEvenetsList: function(text, id) {
        var index = id[id.length - 1];
        if (index != 3) {
            var naviObj = new kony.mvc.Navigation("frmEventsList");
            var eventObject = {
                "text": text,
                "id": id
            };
            naviObj.navigate(eventObject);
        }
    },
    onNavigate: function() {
        this.view.hamburgerevents.typeSelected(null, "flx3");
    },
    toggleLoadingScreen: function(isLoadingVisible) {
        if (isLoadingVisible) this.view.flxThrobberWrapper.isVisible = isLoadingVisible;
        else this.view.flxThrobberWrapper.isVisible = isLoadingVisible;
        this.view.forceLayout();
    },
    onBreakPointChange: function(breakPointValue) {
        if (breakPointValue <= 479) {
            this.view.hamburgerevents.isVisible = false;
            this.view.flxProfileHeader.height = "10%";
            this.view.flxProfileHeader.left = "0%";
            this.view.flxProfileHeader.top = "0%";
            this.view.userprofile.left = "0%";
            this.view.userprofile.width = "100%";
            this.view.userprofile.height = "90%";
            this.view.userprofile.top = "12%";
            this.view.userprofile.centerX = null;
            this.view.userprofile.changeLayoutForBreakPoint(breakPointValue);
        }
    }
});
define("frmProfileControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** logoutSuccess defined for hamburgerevents **/
    AS_UWI_e53103ecfd444fddac0edd6bb80eeed4: function AS_UWI_e53103ecfd444fddac0edd6bb80eeed4() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLogin");
        ntf.navigate();
    },
    /** logoutFailure defined for hamburgerevents **/
    AS_UWI_d4131637e84b486090f7818a1777237a: function AS_UWI_d4131637e84b486090f7818a1777237a() {
        var self = this;
        alert("logout operation failed");
    },
    /** eventTypeChoosen defined for hamburgerevents **/
    AS_UWI_c43c522ee80049f9ab1234b4d280d5ff: function AS_UWI_c43c522ee80049f9ab1234b4d280d5ff(text, id) {
        var self = this;
        this.navigateFrmEvenetsList(text, id);
    },
    /** createEvent defined for hamburgerevents **/
    AS_UWI_d04677f15e3945ad9a448d43f18ea895: function AS_UWI_d04677f15e3945ad9a448d43f18ea895() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmCreateEvent");
        ntf.navigate();
    },
    /** showLoading defined for hamburgerevents **/
    AS_UWI_a727b5704fa64b0cadddf1de01298e5a: function AS_UWI_a727b5704fa64b0cadddf1de01298e5a(bool) {
        var self = this;
        this.toggleLoadingScreen(bool);
    },
    /** invokeLoadingScreen defined for userprofile **/
    AS_UWI_a8f9060a6efb40698e5ee7507405b19d: function AS_UWI_a8f9060a6efb40698e5ee7507405b19d(isVisible) {
        var self = this;
        this.toggleLoadingScreen(isVisible);
    },
    /** onBreakpointChange defined for frmProfile **/
    AS_Form_j870b5dcf12642778ff6aefbdc02142f: function AS_Form_j870b5dcf12642778ff6aefbdc02142f(eventobject, breakpoint) {
        var self = this;
        this.onBreakPointChange(breakpoint);
    }
});
define("frmProfileController", ["userfrmProfileController", "frmProfileControllerActions"], function() {
    var controller = require("userfrmProfileController");
    var controllerActions = ["frmProfileControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
