define("userfrmSessionDetailsController", {
    //Type your controller code here 
    popUpOpinions: function(eventSessionData, opinionType) {
        if (opinionType != 4) {
            this.view.flxAirContainer.shadowDepth = 5;
            this.view.flxAirContainer.shadowType = constants.VIEW_BOUNDS_SHADOW;
            this.view.opinionclient.eventId = eventSessionData.eventId;
            this.view.opinionclient.sessionId = eventSessionData.sessionId;
            this.view.opinionclient.opinionType = opinionType;
            this.view.opinionclient.getOpinions(eventSessionData.sessionName);
            this.view.flxBlocker.isVisible = true;
            this.view.forceLayout();
        } else {
            var config = {
                "event_id": eventSessionData.eventId,
                "session_id": eventSessionData.sessionId,
                "user_id": kony.store.getItem("currentUserInfo").user_id,
                "name": eventSessionData.sessionName,
                "username": kony.store.getItem("currentUserInfo").first_name,
                "user_profile": kony.store.getItem("currentUserInfo").profile_pic_url,
            };
            this.view.discussionList.setDiscussion(config);
            this.view.discussionList.isVisible = true;
            this.view.forceLayout();
        }
    },
    dimissPopup: function() {
        this.view.flxBlocker.isVisible = false;
    },
    onNavigate: function(sessiondetails) {
        if (sessiondetails !== undefined) this.view.sessiondetail.setSessionData(sessiondetails);
    },
    navigateToEventList: function(text, id) {
        var config = {
            "text": text,
            "id": id
        };
        var ntf = new kony.mvc.Navigation("frmEventsList");
        ntf.navigate(config);
    },
    navigateFrmEvenetsList: function(text, id) {
        var index = id[id.length - 1];
        if (index != 3) {
            var naviObj = new kony.mvc.Navigation("frmEventsList");
            var eventObject = {
                "text": text,
                "id": id
            };
            naviObj.navigate(eventObject);
        }
    },
    showLoadingScreen: function(isLoadingVisible) {
        this.view.flxThrobberWrapper.isVisible = isLoadingVisible;
        this.view.forceLayout();
    },
    onBreakPointChange: function(breakPointValue) {
        if (breakPointValue <= 479) {
            this.view.flxLeftMenu.isVisible = false;
            this.view.flxSessionDetails.left = "0%";
            this.view.flxSessionDetails.width = "100%";
            this.view.flxBack.width = "100%";
            this.view.sessiondetail.changeLayoutForBreakPoint(breakPointValue);
        }
    },
    onChangeInBreakpoint: function(breakpoint) {
        setBreakpointValue(breakpoint);
        this.view.opinionclient.onBreakPointChange(breakpoint);
        if (breakpoint > 479 && breakpoint <= 1200) {
            this.view.flxClose.top = "5%";
        } else if (breakpoint <= 479) {
            this.view.discussionList.onBreakPointChange(breakpoint);
            this.view.flxClose.top = "5%";
            this.view.flxLevel2Container.width = "100%";
            this.view.flxAirContainer.width = "100%";
            this.view.opinionclient.width = "100%";
            this.view.forceLayout();
        }
    }
});
define("frmSessionDetailsControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** logoutSuccess defined for hamburgerevents **/
    AS_UWI_a7a18a1fed2447dca3418fa8488f5573: function AS_UWI_a7a18a1fed2447dca3418fa8488f5573() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLogin");
        ntf.navigate();
    },
    /** logoutFailure defined for hamburgerevents **/
    AS_UWI_i3f9e30ccffc439e8f976f712b512831: function AS_UWI_i3f9e30ccffc439e8f976f712b512831() {
        var self = this;
        alert(" Logout operation failed");
    },
    /** eventTypeChoosen defined for hamburgerevents **/
    AS_UWI_f9b9aa6401034272b77f04d30e06f10f: function AS_UWI_f9b9aa6401034272b77f04d30e06f10f(text, id) {
        var self = this;
        this.navigateFrmEvenetsList(text, id);
    },
    /** onClickOfEditProfile defined for hamburgerevents **/
    AS_UWI_e0997434875f494c8ce6172b469e71b1: function AS_UWI_e0997434875f494c8ce6172b469e71b1() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProfile");
        ntf.navigate();
    },
    /** createEvent defined for hamburgerevents **/
    AS_UWI_c42d032f1fec4058b7e4025b901c49a0: function AS_UWI_c42d032f1fec4058b7e4025b901c49a0() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmCreateEvent");
        ntf.navigate();
    },
    /** showLoading defined for hamburgerevents **/
    AS_UWI_d4a7b75ddedf42cf81b5badf212a0f96: function AS_UWI_d4a7b75ddedf42cf81b5badf212a0f96(bool) {
        var self = this;
        this.showLoadingScreen(bool);
    },
    /** onClick defined for flxBack **/
    AS_FlexContainer_d0253aa1b04345468b02664a25ad39ab: function AS_FlexContainer_d0253aa1b04345468b02664a25ad39ab(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmEventDetails");
        ntf.navigate();
    },
    /** onOpinionItemClick defined for sessiondetail **/
    AS_UWI_f7dfc4c41c604e91b892e79da33dd5dc: function AS_UWI_f7dfc4c41c604e91b892e79da33dd5dc(eventSessionData, opinionType) {
        var self = this;
        this.popUpOpinions(eventSessionData, opinionType);
    },
    /** invokeLoadingScreen defined for sessiondetail **/
    AS_UWI_j78d1d7a4d3b4c8ea77b576ba2b5a603: function AS_UWI_j78d1d7a4d3b4c8ea77b576ba2b5a603(isVisible) {
        var self = this;
        this.showLoadingScreen(isVisible);
    },
    /** onClick defined for flxClose **/
    AS_FlexContainer_b29a66c5f5414a6699b965918cd8ed49: function AS_FlexContainer_b29a66c5f5414a6699b965918cd8ed49(eventobject) {
        var self = this;
        this.dimissPopup();
    },
    /** showLoading defined for opinionclient **/
    AS_UWI_bb0a00787ab7461880eeb4a04fb3bf38: function AS_UWI_bb0a00787ab7461880eeb4a04fb3bf38(bool) {
        var self = this;
        this.showLoadingScreen(bool);
    },
    /** invokeLoadingScreen defined for discussionList **/
    AS_UWI_cb0354cd2244464881defa21bbc35db5: function AS_UWI_cb0354cd2244464881defa21bbc35db5(isLoadingVisible) {
        var self = this;
        this.showLoadingScreen(isLoadingVisible);
    },
    /** onBreakpointChange defined for frmSessionDetails **/
    AS_Form_acc454c0d98345ea813ec78c2dac0893: function AS_Form_acc454c0d98345ea813ec78c2dac0893(eventobject, breakpoint) {
        var self = this;
        this.onChangeInBreakpoint(breakpoint);
        this.onBreakPointChange(breakpoint);
    }
});
define("frmSessionDetailsController", ["userfrmSessionDetailsController", "frmSessionDetailsControllerActions"], function() {
    var controller = require("userfrmSessionDetailsController");
    var controllerActions = ["frmSessionDetailsControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
