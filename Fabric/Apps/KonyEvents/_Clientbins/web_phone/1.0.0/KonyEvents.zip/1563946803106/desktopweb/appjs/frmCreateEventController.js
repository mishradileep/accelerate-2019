define("userfrmCreateEventController", {
    //Type your controller code here 
    onNavigate: function(events) {
        if (events) {
            this.view.createEventAndSessions.setSessionAndEventData(events);
        }
        this.view.hamburgerevents.typeSelected(null, "flx5");
    },
    navigateFrmEventsList: function(text, id) {
        var index = id[id.length - 1];
        if (index != 3) {
            var naviObj = new kony.mvc.Navigation("frmEventsList");
            var eventObject = {
                "text": text,
                "id": id
            };
            naviObj.navigate(eventObject);
        }
    },
});
define("frmCreateEventControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** logoutSuccess defined for hamburgerevents **/
    AS_UWI_bfa44cccdc4f4b4e8a4d539255334952: function AS_UWI_bfa44cccdc4f4b4e8a4d539255334952() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmLogin");
        ntf.navigate();
    },
    /** eventTypeChoosen defined for hamburgerevents **/
    AS_UWI_a6eb435ad5024f839492cf933e9cbd76: function AS_UWI_a6eb435ad5024f839492cf933e9cbd76(text, id) {
        var self = this;
        this.navigateFrmEventsList(text, id);
    },
    /** onClickOfEditProfile defined for hamburgerevents **/
    AS_UWI_jb6b218cf1c641918565049528121655: function AS_UWI_jb6b218cf1c641918565049528121655() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmProfile");
        ntf.navigate();
    },
    /** onPublishSuccess defined for createEventAndSessions **/
    AS_UWI_fb135bcf2d5e434e8c95f661a893525a: function AS_UWI_fb135bcf2d5e434e8c95f661a893525a() {
        var self = this;
        var ntf = new kony.mvc.Navigation("frmEventsList");
        ntf.navigate();
    }
});
define("frmCreateEventController", ["userfrmCreateEventController", "frmCreateEventControllerActions"], function() {
    var controller = require("userfrmCreateEventController");
    var controllerActions = ["frmCreateEventControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
