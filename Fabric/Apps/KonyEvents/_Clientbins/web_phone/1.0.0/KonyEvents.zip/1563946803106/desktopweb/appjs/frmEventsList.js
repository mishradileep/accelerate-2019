define("frmEventsList", function() {
    return function(controller) {
        function addWidgetsfrmEventsList() {
            this.setDefaultUnit(kony.flex.DP);
            var headermenubar = new com.konymp.headermenubar({
                "clipBounds": true,
                "height": "100%",
                "id": "headermenubar",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "headermenubar": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            headermenubar.enableHamburgerEvents = true;
            headermenubar.eventChoosen = controller.AS_UWI_g6758d1351f64ef9b01c35a269ae9815;
            headermenubar.editProfileChoosen = controller.AS_UWI_h6985be6421340319d53adfcb8883f32;
            headermenubar.logoutSuccessEvent = controller.AS_UWI_b19b48a8d08f4e0cabad28caae406810;
            headermenubar.logoutFailureEvent = controller.AS_UWI_id08e8f86517477e9b775f80da99316a;
            headermenubar.editEvent = controller.AS_UWI_h464d6d96c5c410294a3e95c7dfe12e8;
            headermenubar.showLoading = controller.AS_UWI_j9a1ebc1ae664062ad7a06ba2c8bcb75;
            headermenubar.createEvent = controller.AS_UWI_f2639e3327b642739be155351d4e0b3f;
            var flxThrobberWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxThrobberWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxLoader",
                "top": "0dp",
                "width": "100%",
                "zIndex": 50
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxThrobberWrapper.setDefaultUnit(kony.flex.DP);
            var flxThrobber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxThrobber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxThrobber",
                "top": "0dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxThrobber.setDefaultUnit(kony.flex.DP);
            var imgLoader = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "8dp",
                "id": "imgLoader",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "loading_strip.gif",
                "top": 0,
                "width": "56dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxThrobber.add(imgLoader);
            flxThrobberWrapper.add(flxThrobber);
            this.add(headermenubar, flxThrobberWrapper);
        };
        return [{
            "addWidgets": addWidgetsfrmEventsList,
            "enabledForIdleTimeout": false,
            "id": "frmEventsList",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_e56a508fc6ee453aa2c51229a8918c49,
            "skin": "sknFormGrey",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [479, 1200, 1336],
            "onBreakpointChange": controller.AS_Form_ad9be9019cbd460787b5e6a8b26b1774
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_c2402b8fee15434f909f94d11cb7821d,
            "retainScrollPosition": false
        }]
    }
});