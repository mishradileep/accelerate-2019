define("frmProfile", function() {
    return function(controller) {
        function addWidgetsfrmProfile() {
            this.setDefaultUnit(kony.flex.DP);
            var hamburgerevents = new com.konymp.hamburgerevents({
                "clipBounds": true,
                "height": "100%",
                "id": "hamburgerevents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "overrides": {
                    "hamburgerevents": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            hamburgerevents.logoutSuccess = controller.AS_UWI_e53103ecfd444fddac0edd6bb80eeed4;
            hamburgerevents.logoutFailure = controller.AS_UWI_d4131637e84b486090f7818a1777237a;
            hamburgerevents.eventTypeChoosen = controller.AS_UWI_c43c522ee80049f9ab1234b4d280d5ff;
            hamburgerevents.createEvent = controller.AS_UWI_d04677f15e3945ad9a448d43f18ea895;
            hamburgerevents.showLoading = controller.AS_UWI_a727b5704fa64b0cadddf1de01298e5a;
            var userprofile = new com.konymp.userprofile({
                "centerX": "60%",
                "clipBounds": true,
                "height": "80%",
                "id": "userprofile",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "27%",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "20%",
                "width": "70%",
                "overrides": {
                    "userprofile": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            userprofile.invokeLoadingScreen = controller.AS_UWI_a8f9060a6efb40698e5ee7507405b19d;
            var flxProfileHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "60.00%",
                "clipBounds": true,
                "height": "15%",
                "id": "flxProfileHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0.00%",
                "width": "70%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxProfileHeader.setDefaultUnit(kony.flex.DP);
            var lblProfileLabel = new kony.ui.Label({
                "centerY": "60%",
                "id": "lblProfileLabel",
                "isVisible": true,
                "left": "0%",
                "skin": "sknProfileLabel",
                "text": "Profile",
                "textStyle": {},
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblLine = new kony.ui.Label({
                "centerX": "50%",
                "height": "1dp",
                "id": "lblLine",
                "isVisible": true,
                "left": "23dp",
                "skin": "sknProfileSeparator",
                "textStyle": {},
                "top": "98%",
                "width": "100%",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxProfileHeader.add(lblProfileLabel, lblLine);
            var flxThrobberWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxThrobberWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxLoader",
                "top": "0dp",
                "width": "100%",
                "zIndex": 50
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxThrobberWrapper.setDefaultUnit(kony.flex.DP);
            var flxThrobber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxThrobber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxThrobber",
                "top": "0dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxThrobber.setDefaultUnit(kony.flex.DP);
            var imgLoader = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "8dp",
                "id": "imgLoader",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "loading_strip.gif",
                "top": 0,
                "width": "56dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxThrobber.add(imgLoader);
            flxThrobberWrapper.add(flxThrobber);
            this.add(hamburgerevents, userprofile, flxProfileHeader, flxThrobberWrapper);
        };
        return [{
            "addWidgets": addWidgetsfrmProfile,
            "enabledForIdleTimeout": false,
            "id": "frmProfile",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFormGrey",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [479, 1024, 1366],
            "onBreakpointChange": controller.AS_Form_j870b5dcf12642778ff6aefbdc02142f
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});