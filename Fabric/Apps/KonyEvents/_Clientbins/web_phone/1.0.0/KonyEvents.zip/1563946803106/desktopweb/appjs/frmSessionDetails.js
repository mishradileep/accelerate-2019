define("frmSessionDetails", function() {
    return function(controller) {
        function addWidgetsfrmSessionDetails() {
            this.setDefaultUnit(kony.flex.DP);
            var flxLeftMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxLeftMenu",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "20%",
                "zIndex": 4
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLeftMenu.setDefaultUnit(kony.flex.DP);
            var hamburgerevents = new com.konymp.hamburgerevents({
                "clipBounds": true,
                "height": "100%",
                "id": "hamburgerevents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "hamburgerevents": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            hamburgerevents.logoutSuccess = controller.AS_UWI_a7a18a1fed2447dca3418fa8488f5573;
            hamburgerevents.logoutFailure = controller.AS_UWI_i3f9e30ccffc439e8f976f712b512831;
            hamburgerevents.eventTypeChoosen = controller.AS_UWI_f9b9aa6401034272b77f04d30e06f10f;
            hamburgerevents.onClickOfEditProfile = controller.AS_UWI_e0997434875f494c8ce6172b469e71b1;
            hamburgerevents.createEvent = controller.AS_UWI_c42d032f1fec4058b7e4025b901c49a0;
            hamburgerevents.showLoading = controller.AS_UWI_d4a7b75ddedf42cf81b5badf212a0f96;
            flxLeftMenu.add(hamburgerevents);
            var flxSessionDetails = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxSessionDetails",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "20%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "80%",
                "zIndex": 4
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxSessionDetails.setDefaultUnit(kony.flex.DP);
            var flxBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "8%",
                "id": "flxBack",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_d0253aa1b04345468b02664a25ad39ab,
                "skin": "sknSessionDetailsBack",
                "top": "0%",
                "width": "23.96%",
                "zIndex": 2
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBack.setDefaultUnit(kony.flex.DP);
            var FlexGroup0f082e3eff92e4f = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": true,
                "height": "15dp",
                "id": "FlexGroup0f082e3eff92e4f",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "5%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "20dp"
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            FlexGroup0f082e3eff92e4f.setDefaultUnit(kony.flex.DP);
            var imgBack = new kony.ui.Image2({
                "centerY": "50%",
                "height": "100%",
                "id": "imgBack",
                "isVisible": true,
                "left": "3%",
                "skin": "slImage",
                "src": "back_button.png",
                "top": "5%",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexGroup0f082e3eff92e4f.add(imgBack);
            var lblBack = new kony.ui.Label({
                "centerY": "50%",
                "height": "100%",
                "id": "lblBack",
                "isVisible": true,
                "left": "20dp",
                "skin": "sknlblBack00a0dd",
                "text": "Back to Event Details",
                "top": "16dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBack.add(FlexGroup0f082e3eff92e4f, lblBack);
            var sessiondetail = new com.konymp.sessiondetail({
                "clipBounds": true,
                "height": "96%",
                "id": "sessiondetail",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "4%",
                "width": "100%",
                "overrides": {
                    "sessiondetail": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            sessiondetail.onOpinionItemClick = controller.AS_UWI_f7dfc4c41c604e91b892e79da33dd5dc;
            sessiondetail.invokeLoadingScreen = controller.AS_UWI_j78d1d7a4d3b4c8ea77b576ba2b5a603;
            flxSessionDetails.add(flxBack, sessiondetail);
            var flxThrobberWrapper = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "100%",
                "id": "flxThrobberWrapper",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxLoader",
                "top": "0dp",
                "width": "100%",
                "zIndex": 50
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxThrobberWrapper.setDefaultUnit(kony.flex.DP);
            var flxThrobber = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "100dp",
                "id": "flxThrobber",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknFlxThrobber",
                "top": "0dp",
                "width": "100dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxThrobber.setDefaultUnit(kony.flex.DP);
            var imgLoader = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "50%",
                "height": "8dp",
                "id": "imgLoader",
                "isVisible": true,
                "left": 0,
                "skin": "slImage",
                "src": "loading_strip.gif",
                "top": 0,
                "width": "56dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxThrobber.add(imgLoader);
            flxThrobberWrapper.add(flxThrobber);
            var flxBlocker = new kony.ui.FlexContainer({
                "clipBounds": true,
                "height": "101%",
                "id": "flxBlocker",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknGreyBlocler",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxBlocker.setDefaultUnit(kony.flex.DP);
            var flxLevel2Container = new kony.ui.FlexContainer({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "90%",
                "id": "flxLevel2Container",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "65%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxLevel2Container.setDefaultUnit(kony.flex.DP);
            var flxClose = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": true,
                "height": "20dp",
                "id": "flxClose",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "95%",
                "isModalContainer": false,
                "onClick": controller.AS_FlexContainer_b29a66c5f5414a6699b965918cd8ed49,
                "skin": "slFbox",
                "top": "5.30%",
                "width": "20dp",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxClose.setDefaultUnit(kony.flex.DP);
            var imgClose = new kony.ui.Image2({
                "height": "100%",
                "id": "imgClose",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "close.png",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxClose.add(imgClose);
            var flxAirContainer = new kony.ui.FlexContainer({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": true,
                "height": "85%",
                "id": "flxAirContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknAirCurve",
                "width": "90%",
                "zIndex": 1
            }, {
                "retainFlowHorizontalAlignment": false
            }, {});
            flxAirContainer.setDefaultUnit(kony.flex.DP);
            var opinionclient = new com.konymp.opinionclient({
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "opinionclient",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknWhiteCurvedBackground",
                "top": "0dp",
                "width": "100%",
                "overrides": {
                    "opinionclient": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            opinionclient.eventId = "1";
            opinionclient.sessionId = "1";
            opinionclient.opinionType = "Poll";
            opinionclient.userId = "1";
            opinionclient.showLoading = controller.AS_UWI_bb0a00787ab7461880eeb4a04fb3bf38;
            flxAirContainer.add(opinionclient);
            flxLevel2Container.add(flxClose, flxAirContainer);
            flxBlocker.add(flxLevel2Container);
            var discussionList = new com.konymp.discussionList({
                "clipBounds": true,
                "height": "100%",
                "id": "discussionList",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "sknDiscussionListBg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 10,
                "overrides": {
                    "discussionList": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "overrides": {}
            }, {
                "overrides": {}
            });
            discussionList.invokeLoadingScreen = controller.AS_UWI_cb0354cd2244464881defa21bbc35db5;
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "479": {
                    "flxBlocker": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        }
                    },
                    "flxLevel2Container": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "width": {
                            "type": "string",
                            "value": "100%"
                        }
                    },
                    "flxClose": {
                        "isVisible": true,
                        "top": {
                            "type": "string",
                            "value": "2.50%"
                        }
                    },
                    "flxAirContainer": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "90%"
                        },
                        "left": {
                            "type": "string",
                            "value": ""
                        },
                        "top": {
                            "type": "string",
                            "value": "5dp"
                        },
                        "width": {
                            "type": "string",
                            "value": "100%"
                        }
                    }
                },
                "1200": {
                    "flxBlocker": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        }
                    }
                }
            }
            this.add(flxLeftMenu, flxSessionDetails, flxThrobberWrapper, flxBlocker, discussionList);
        };
        return [{
            "addWidgets": addWidgetsfrmSessionDetails,
            "enabledForIdleTimeout": false,
            "id": "frmSessionDetails",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknFormGrey",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [479, 1200, 1366],
            "onBreakpointChange": controller.AS_Form_acc454c0d98345ea813ec78c2dac0893
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});