{
    "theme_color": "#004581",
    "orientation": "any",
    "background_color": "#004581",
    "display": "standalone",
    "name": "KonyEvents",
    "id": "KonyEvents",
    "short_name": "KonyEvents",
    "start_url": "/apps/KonyEvents/",
    "icons": [{
        "sizes": "72x72",
        "type": "image/png",
        "src": "images/kony_76.png"
    }, {
        "type": "image/png",
        "sizes": "192x192",
        "src": "images/kony_152.png"
    }, {
        "type": "image/png",
        "sizes": "512x512",
        "src": "images/kony_180.png"
    }],
    "related_applications": [{
        "platform": "web",
        "url": "http://localhost:port/apps/Demo/"
    }]
}